create function least10(v_an number)
    return least10_ret
    is
    returnval least10_ret;
begin
    if (existaAn(v_an)) then
        select least10_ret(id, titlu_curs, cnt)
        into returnval
        from (
                 select c.id as id, c.titlu_curs as titlu_curs, count(n.id) as cnt
                 from CURSURI c
                          join note n on c.ID = n.ID_CURS
                 where n.VALOARE = 10
                   and c.AN = v_an
                 group by c.id, c.titlu_curs
                 order by count(n.id)
             )
        where rownum = 1;
        return returnval;
    else
        select least10_ret(id, titlu_curs, cnt)
        into returnval
        from (
                 select c.id as id, c.titlu_curs as titlu_curs, count(n.id) as cnt
                 from CURSURI c
                          join note n on c.ID = n.ID_CURS
                 where n.VALOARE = 10
                 group by c.id, c.titlu_curs
                 order by count(n.id), c.id
             )
        where rownum = 1;
        return returnval;
    end if;
end;
/

