create type recommendation is object
(
    id      number,
    nume    varchar2(15),
    prenume varchar2(30),
    count   number
)
/

