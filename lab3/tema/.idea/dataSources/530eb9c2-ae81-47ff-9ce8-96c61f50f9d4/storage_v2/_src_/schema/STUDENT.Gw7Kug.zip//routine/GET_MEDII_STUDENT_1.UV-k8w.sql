create procedure get_medii_student_1(IN_id IN studenti.id%type, OUT_medie1 OUT float, OUT_medie2 OUT float)
as
  p_exist boolean;
begin
  p_exist := f_exista_student(IN_id);
    if p_exist = true then
      select trunc(avg(valoare),2)
      into OUT_medie1
      from note n join cursuri c on n.id_curs=c.id
      where an=1 and n.id_student = IN_id;
      select trunc(avg(valoare),2)
      into OUT_medie2
      from note n join cursuri c on n.id_curs=c.id
      where an=2 and n.id_student = IN_id;
  end if;
end;
/

