create procedure p_afiseaza_varsta
  is
  p_numar_studenti number(5);
  p_student_random number(5);
  p_rezultat VARCHAR(1000);
begin
  select count(*)
  into p_numar_studenti
  from studenti;
  p_student_random := dbms_random.value(1,p_numar_studenti);
  select id||' '||nume||' '||prenume||' '||varsta
  into p_rezultat
  from
  (select id,nume,prenume,trunc(months_between(sysdate,data_nastere)/12)||' ani '||
          floor(to_number(months_between(sysdate,data_nastere)-(trunc(months_between(sysdate,data_nastere)/12))*12))||' luni '||
          floor(to_number(sysdate-add_months(data_nastere,trunc(months_between(sysdate,data_nastere)))))||' zile. ' as varsta, rownum as rand
  from studenti)
  where rand = p_student_random;
  dbms_output.put_line(p_rezultat);
end p_afiseaza_varsta;
/

