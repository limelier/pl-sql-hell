create type student_object is object
(
    student_id      number,
    student_nume    varchar2(100),
    student_prenume varchar2(100)
)
/

