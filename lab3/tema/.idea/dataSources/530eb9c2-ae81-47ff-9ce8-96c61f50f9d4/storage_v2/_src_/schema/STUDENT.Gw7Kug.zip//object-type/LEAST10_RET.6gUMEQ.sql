create type least10_ret is object
(
    id         number,
    titlu_curs varchar2(52),
    nr_note    number
)
/

