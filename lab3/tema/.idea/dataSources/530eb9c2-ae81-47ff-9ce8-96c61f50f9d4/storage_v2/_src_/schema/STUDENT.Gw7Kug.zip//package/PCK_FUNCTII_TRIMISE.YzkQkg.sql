create package pck_functii_trimise
is
    function get_scadenta(IN_data_scadenta date) return varchar2;
    function get_bursa_neta(IN_id studenti.id%type) return varchar2;
    function get_students_id return num_arr;
    function get_students_details return student_table;
    function get_repartitie_zodii return repartitie_zodii_table;
    function get_medii_intregi_prieteni(IN_id studenti.id%type) return medii_intregi_prieteni_table;
    function compara_studenti(IN_id1 studenti.id%type, IN_id2 studenti.id%type) return medii_studenti_table;
end pck_functii_trimise;
/

