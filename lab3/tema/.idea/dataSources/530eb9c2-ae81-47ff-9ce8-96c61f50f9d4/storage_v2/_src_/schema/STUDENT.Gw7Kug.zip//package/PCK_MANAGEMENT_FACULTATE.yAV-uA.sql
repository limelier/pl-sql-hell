create package pck_management_facultate
is
  procedure p_afiseaza_varsta;--daca se cere sa se afiseze random
  function f_exista_student(IN_id in studenti.id%type) return boolean;--functie ajutatoare
  function f_are_note(IN_id_student in note.id_student%type) return boolean;--functie ajutatoare
  function f_exista_in_prieteni(IN_id_student in prieteni.id_student1%type) return boolean;--functie ajutatoare
  procedure p_afiseaza_varsta1(IN_id studenti.id%type);--daca se cere sa se dea ca parametru un id de student scris de la tastatura
  procedure p_add_student_studenti;
  procedure p_add_student_note(IN_id studenti.id%type);
  procedure p_del_student(IN_id studenti.id%type);
  procedure p_detalii_student(IN_id in studenti.id%type,p_medie1 out float,p_medie2 out float);
end pck_management_facultate;
/

