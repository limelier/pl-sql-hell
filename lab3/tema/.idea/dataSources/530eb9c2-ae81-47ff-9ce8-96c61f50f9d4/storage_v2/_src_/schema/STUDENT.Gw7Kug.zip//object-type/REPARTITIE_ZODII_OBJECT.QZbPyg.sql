create type repartitie_zodii_object is object
(
    nume_zodie  varchar2(100),
    nr_studenti number
)
/

