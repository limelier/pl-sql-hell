create procedure get_interval_prieteni
as
  p_student1_arr num_arr;
  p_student2_arr num_arr;
begin
  select student1, student2
  bulk collect into p_student1_arr, p_student2_arr
  from
    (select s1.id as student1, s2.id as student2
    from studenti s1 join prieteni p on p.id_student1=s1.id join studenti s2 on s2.id=p.id_student2
    where p.id between 3000 and 4000 order by 1);

  if p_student1_arr.count<>0 then
    forall i in p_student1_arr.first .. p_student1_arr.last
      insert into interval_prieteni(id_student1, id_student2) values (p_student1_arr(i), p_student2_arr(i));
  end if;

end;
/

