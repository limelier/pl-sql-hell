create procedure modif_burse
as
BEGIN
    update STUDENTI
        set bursa = bursa + mod(extract(YEAR from DATA_NASTERE), 10);
end modif_burse;
/

