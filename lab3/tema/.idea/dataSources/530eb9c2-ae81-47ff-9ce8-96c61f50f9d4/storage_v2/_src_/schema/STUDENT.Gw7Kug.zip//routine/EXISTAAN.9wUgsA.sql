create function existaAn(v_an number)
    return boolean
    is
    apar number;
begin
    select count(an) into apar from cursuri;
    if apar = 0 then
        return false;
    else
        return true;
    end if;
end;
/

