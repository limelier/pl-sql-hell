create function get_recommendations(sid STUDENTI.ID%TYPE)
    return recommendations
    is
    recommended recommendations;
begin
    select recommendation(id, nume, prenume, count)
        bulk collect
    into recommended
    from (
             select id, nume, prenume, count(friend) as count
             from (
                      select s.ID as id, s.NUME as nume, s.PRENUME as prenume, p2.ID_STUDENT1 as friend
                      from prieteni p1
                               join prieteni p2 on p1.ID_STUDENT2 = p2.ID_STUDENT1
                               join studenti s on p2.ID_STUDENT2 = s.ID
                      where p1.ID_STUDENT1 = sid
                  )
             group by id, nume, prenume
             order by count(friend) desc
         )
    where rownum <= 5;
    return recommended;
end;
/

