create function get_bursa_neta(IN_id studenti.id%type)
    return varchar2
    is
    p_impozit      number := 0;
    p_bursa_neta   number := 0;
    p_bursa        number := 0;
    p_detail       varchar2(200);
    p_exista_bursa number;
begin
    select count(bursa) into p_exista_bursa from studenti where id = IN_id;
    if p_exista_bursa = 0 then
        p_detail := 'Studentul nu are bursa';
    else
        select bursa into p_bursa from studenti where id = IN_id;
        if p_bursa < 1000 then
            p_impozit := 0;
        elsif p_bursa between 1000 and 1099 then
            p_impozit := p_bursa * 0.1;
        elsif p_bursa between 1100 and 1199 then
            p_impozit := p_bursa * 0.2;
        elsif p_bursa >= 1200 then
            p_impozit := p_bursa * 0.4;
        end if;
        p_bursa_neta := p_bursa - p_impozit;
        p_detail := 'Studentul cu id-il' || IN_id || ' are bursa ' || p_bursa || ' si bursa neta de ' || p_bursa_neta;
    end if;
    return p_detail;
END get_bursa_neta;
/

