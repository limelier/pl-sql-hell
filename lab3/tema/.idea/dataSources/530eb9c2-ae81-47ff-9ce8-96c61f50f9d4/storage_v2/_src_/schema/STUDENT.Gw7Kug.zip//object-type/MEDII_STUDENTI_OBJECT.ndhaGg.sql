create type medii_studenti_object is object
(
    id_student1      number,
    nume_student1    varchar2(100),
    prenume_student1 varchar2(100),
    medie_student1   number,
    id_student2      number,
    nume_student2    varchar2(100),
    prenume_student2 varchar2(100),
    medie_student2   number
)
/

