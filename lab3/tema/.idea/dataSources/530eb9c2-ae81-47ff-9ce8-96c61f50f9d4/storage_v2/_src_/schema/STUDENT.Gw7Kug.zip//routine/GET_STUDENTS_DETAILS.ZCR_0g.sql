create function get_students_details
    return student_table
    is
    student_table_arr student_table := student_table();
begin
    select student_object(student_id, student_nume, student_prenume)
        bulk collect
    into student_table_arr
    from (select s.id as student_id, s.nume as student_nume, s.prenume as student_prenume
          from studenti s
                   join note n on n.id_student = s.id
                   join cursuri c on c.id = n.id_curs
          where titlu_curs = 'Baze de date'
            and valoare = 10);
    return student_table_arr;
end;
/

